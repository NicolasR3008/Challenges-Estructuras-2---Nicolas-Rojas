import { useState, useEffect } from 'react';
import { useCollection } from '../firebase/firestore';

export const Crud = () => {
  const [item, setItem] = useState({ name: '' });
  const [editingId, setEditingId] = useState(null);
  const { add, getAll, update, remove, results, isPending } = useCollection("items");

  useEffect(() => {
    getAll();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingId) {
      await update(editingId, item);
      setEditingId(null);
    } else {
      await add(item);
    }
    setItem({ name: '' });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          value={item.name}
          onChange={(e) => setItem({ name: e.target.value })}
          placeholder="Item name"
        />
        <button type="submit">
          {editingId ? "Actualizar" : "Guardar"}
        </button>
      </form>

      {isPending && <p>Cargando...</p>}

      <ul>
        {results.map((doc) => (
          <li key={doc.id}>
            {doc.name}
            <button onClick={() => {
              setItem({ name: doc.name });
              setEditingId(doc.id);
            }}>
              Editar
            </button>
            <button onClick={() => remove(doc.id)}>
              Eliminar
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};