import { db } from './config';
import { 
  collection, 
  addDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  doc 
} from "firebase/firestore";

export const useCollection = (table) => {
  // ... código existente ...

  const update = async (id, newData) => {
    setIsPending(true);
    try {
      const docRef = doc(db, table, id);
      await updateDoc(docRef, newData);
      await getAll();
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setIsPending(false);
    }
  };

  const remove = async (id) => {
    setIsPending(true);
    try {
      const docRef = doc(db, table, id);
      await deleteDoc(docRef);
      await getAll();
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setIsPending(false);
    }
  };

  return { add, getAll, update, remove, results, isPending, error };
};