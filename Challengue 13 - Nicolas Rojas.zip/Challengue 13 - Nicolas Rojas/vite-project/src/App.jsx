import { useSelector } from 'react-redux';
import { LoginForm } from './components/LoginForm';
import { GoogleAuth } from './components/GoogleAuth';
import { LogoutButton } from './components/LogoutButton';
import MessageComponent from './components/MessageComponent';

function App() {
    const { status } = useSelector(state => state.auth);

    return (
        <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
            {status === 'authenticated' ? (
                <div>
                    <h1>Chat Firebase</h1>
                    <MessageComponent />
                    <LogoutButton />
                </div>
            ) : (
                <div>
                    <h2>Inicio de sesión</h2>
                    <LoginForm />
                    <p style={{ margin: '15px 0' }}>o</p>
                    <GoogleAuth />
                </div>
            )}
        </div>
    );
}

export default App;