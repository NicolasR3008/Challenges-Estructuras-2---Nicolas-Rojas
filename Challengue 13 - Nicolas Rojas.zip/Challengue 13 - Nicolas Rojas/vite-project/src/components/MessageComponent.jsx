import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { listenMessages, sendMessage } from "../store/slices/firebaseThunks";

const MessageComponent = () => {
    const dispatch = useDispatch();
    const [newMessage, setNewMessage] = useState("");
    const { messages, loading, error } = useSelector((state) => state.firebase);
    const { uid, displayName } = useSelector((state) => state.auth);

    useEffect(() => {
        dispatch(listenMessages());
    }, [dispatch]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (newMessage.trim()) {
            dispatch(sendMessage({
                text: newMessage,
                user: displayName || "Anónimo",
                userId: uid
            }));
            setNewMessage("");
        }
    };

    return (
        <div>
            <h2>Chat en tiempo real</h2>
            
            {error && <p style={{ color: 'red' }}>{error}</p>}
            
            <div style={{ height: '300px', overflowY: 'auto', border: '1px solid #ccc' }}>
                {loading ? (
                    <p>Cargando mensajes...</p>
                ) : (
                    messages.map((message) => (
                        <div key={message.id} style={{ margin: '10px', padding: '5px', borderBottom: '1px solid #eee' }}>
                            <strong>{message.user}:</strong> {message.text}
                        </div>
                    ))
                )}
            </div>

            <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
                <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Escribe tu mensaje..."
                    style={{ width: '70%', padding: '8px' }}
                />
                <button
                    type="submit"
                    style={{ marginLeft: '10px', padding: '8px 15px' }}
                >
                    Enviar
                </button>
            </form>
        </div>
    );
};

export default MessageComponent;