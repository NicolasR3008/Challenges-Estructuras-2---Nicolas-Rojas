import { initializeApp } from "firebase/app";
import { getAuth } from 'firebase/auth';
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyAIz5wyoY1_6iZCSlyzBWP4cejL0e5LaA",
    authDomain: "vue-demo-1c3f5.firebaseapp.com",
    databaseURL: "https://vue-demo-1c3f5-default-rtdb.firebaseio.com", 
    projectId: "vue-demo-1c3f5",
    storageBucket: "vue-demo-1c3f5.appspot.com",
    messagingSenderId: "318224169700",
    appId: "1:318224169700:web:51362c4bf539f5487c0af1" 
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

export { app, auth, db };
