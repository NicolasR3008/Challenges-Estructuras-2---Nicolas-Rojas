import { createSlice } from "@reduxjs/toolkit";

const firebaseSlice = createSlice({
    name: "firebase",
    initialState: {
        messages: [],
        loading: false,
        error: null
    },
    reducers: {
        setLoading: (state) => {
            state.loading = true;
            state.error = null;
        },
        setMessages: (state, action) => {
            state.messages = action.payload;
            state.loading = false;
        },
        setError: (state, action) => {
            state.error = action.payload;
            state.loading = false;
        }
    }
});

export const { setLoading, setMessages, setError } = firebaseSlice.actions;
export default firebaseSlice.reducer;