import { db } from '../../firebase/config';
import { ref, push, onValue } from "firebase/database";
import { setLoading, setMessages, setError } from './firebaseSlice';

export const listenMessages = () => (dispatch) => {
    dispatch(setLoading());
    try {
        const messagesRef = ref(db, 'messages');
        onValue(messagesRef, (snapshot) => {
            const data = snapshot.val();
            const messages = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            })) : [];
            dispatch(setMessages(messages));
        });
    } catch (error) {
        dispatch(setError(error.message));
    }
};

export const sendMessage = (messageData) => (dispatch) => {
    dispatch(setLoading());
    try {
        const messagesRef = ref(db, 'messages');
        push(messagesRef, {
            ...messageData,
            timestamp: Date.now()
        });
    } catch (error) {
        dispatch(setError(error.message));
    }
};