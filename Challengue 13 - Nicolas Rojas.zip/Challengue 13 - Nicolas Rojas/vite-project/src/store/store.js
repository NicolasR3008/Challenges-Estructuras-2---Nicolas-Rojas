import { configureStore } from '@reduxjs/toolkit';
import { authSlice } from './slices/authSlice';
import firebaseReducer from './slices/firebaseSlice';

export const store = configureStore({
    reducer: {
        auth: authSlice.reducer,
        firebase: firebaseReducer
    }
});