//Nicolas Rojas Cabal - 2226088


"use client"

import { useState } from "react"
import TreeVisualizer from "./components/TreeVisualizer"
import BinarySearchTree from "./components/BinarySearchTree"
import "./App.css"

export default function App() {
  const [tree] = useState(() => {
    const bst = new BinarySearchTree()
    ;[45, 25, 65, 15, 35, 55, 75].forEach((value) => bst.insert(value))
    return bst
  })

  const [traversals] = useState({
    inOrder: tree.inOrder(),
    preOrder: tree.preOrder(),
    postOrder: tree.postOrder(),
  })

  const [searchValue, setSearchValue] = useState("")
  const [searchResult, setSearchResult] = useState(null)

  const handleSearch = () => {
    const value = Number.parseInt(searchValue)
    if (!isNaN(value)) {
      setSearchResult(tree.contains(value))
    }
  }

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Visualizador de Árbol Binario</h1>
      </header>

      <div className="traversal-info">
        <div className="traversal-box">
          <h3>Recorridos del Árbol</h3>
          <p>
            <strong>InOrder:</strong> {traversals.inOrder.join(", ")}
          </p>
          <p>
            <strong>PreOrder:</strong> {traversals.preOrder.join(", ")}
          </p>
          <p>
            <strong>PostOrder:</strong> {traversals.postOrder.join(", ")}
          </p>
        </div>

        <div className="search-box">
          <h3>Buscar Valor</h3>
          <div className="search-controls">
            <input
              type="number"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Ingrese un valor"
            />
            <button onClick={handleSearch}>Buscar</button>
          </div>
          {searchResult !== null && (
            <p className={searchResult ? "found" : "not-found"}>
              {searchResult
                ? `¡El valor ${searchValue} existe en el árbol!`
                : `El valor ${searchValue} no existe en el árbol.`}
            </p>
          )}
        </div>
      </div>

      <div className="tree-container">
        <TreeVisualizer rootNode={tree.root} />
      </div>
    </div>
  )
}
