//Nicolas Rojas Cabal - 2226088

/**
 */
class TreeNode {
  constructor(value) {
    this.value = value
    this.left = null
    this.right = null
  }

  isLeaf() {
    return this.left === null && this.right === null
  }
}

/**
 */
export default class BinarySearchTree {
  constructor() {
    this.root = null
  }

  /**
   * @param {number} value 
   */
  insert(value) {
    const newNode = new TreeNode(value)

    if (this.root === null) {
      this.root = newNode
      return
    }

    const insertNode = (node, newNode) => {
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode
        } else {
          insertNode(node.left, newNode)
        }
      }
      else if (newNode.value > node.value) {
        if (node.right === null) {
          node.right = newNode
        } else {
          insertNode(node.right, newNode)
        }
      }
    }

    insertNode(this.root, newNode)
  }

  /**
   * @returns {Array} 
   */
  inOrder() {
    const result = []

    const traverse = (node) => {
      if (node !== null) {
        traverse(node.left)
        result.push(node.value)
        traverse(node.right)
      }
    }

    traverse(this.root)
    return result
  }

  /**
   * @returns {Array} 
   */
  preOrder() {
    const result = []

    const traverse = (node) => {
      if (node !== null) {
        result.push(node.value)
        traverse(node.left)
        traverse(node.right)
      }
    }

    traverse(this.root)
    return result
  }

  /**
   * @returns {Array} 
   */
  postOrder() {
    const result = []

    const traverse = (node) => {
      if (node !== null) {
        traverse(node.left)
        traverse(node.right)
        result.push(node.value)
      }
    }

    traverse(this.root)
    return result
  }

  /**
   * @param {number} value 
   * @returns {boolean} 
   */
  contains(value) {
    let current = this.root

    while (current !== null) {
      if (value === current.value) {
        return true
      }

      if (value < current.value) {
        current = current.left
      } else {
        current = current.right
      }
    }

    return false
  }
}
