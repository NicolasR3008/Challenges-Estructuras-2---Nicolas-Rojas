//Nicolas Rojas Cabal - 2226088


"use client"

import { useEffect, useState } from "react"
import Tree from "react-d3-tree"

/**
 * @param {Object} node - 
 * @returns {Object} 
 */
function convertToD3Format(node) {
  if (!node) return null

  const d3Node = {
    name: node.value.toString(),
    attributes: {
      isLeaf: node.left === null && node.right === null,
    },
    children: [],
  }

  if (node.left) {
    d3Node.children.push(convertToD3Format(node.left))
  }

  if (node.right) {
    d3Node.children.push(convertToD3Format(node.right))
  }

  return d3Node
}


export default function TreeVisualizer({ rootNode }) {
  const [treeData, setTreeData] = useState(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const [translate, setTranslate] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (rootNode) {
      setTreeData(convertToD3Format(rootNode))
    }
  }, [rootNode])

  useEffect(() => {
    const updateDimensions = () => {
      const containerElement = document.querySelector(".tree-container")
      if (containerElement) {
        const { width, height } = containerElement.getBoundingClientRect()
        setDimensions({ width, height })
        setTranslate({ x: width / 2, y: 80 })
      }
    }

    const timer = setTimeout(updateDimensions, 100)

    updateDimensions()
    window.addEventListener("resize", updateDimensions)

    return () => {
      clearTimeout(timer)
      window.removeEventListener("resize", updateDimensions)
    }
  }, [])

  const nodeStyles = {
    circle: {
      fill: "#4CAF50",
      stroke: "#2E7D32",
      strokeWidth: 2,
    },
    text: {
      fill: "#333",
      fontSize: 14,
      fontWeight: "bold",
    },
  }

  if (!treeData) {
    return <div>Cargando árbol...</div>
  }

  return (
    <div style={{ width: "100%", height: "100%" }}>
      <Tree
        data={treeData}
        orientation="vertical"
        translate={translate}
        nodeSize={{ x: 150, y: 100 }}
        separation={{ siblings: 1.2, nonSiblings: 1.5 }}
        pathFunc="step"
        centeringTransitionDuration={0}
        renderCustomNodeElement={(rd3tProps) => (
          <g>
            <circle
              r={20}
              cx={0}
              cy={0}
              fill={rd3tProps.nodeDatum.attributes?.isLeaf ? "#8BC34A" : "#4CAF50"}
              stroke={nodeStyles.circle.stroke}
              strokeWidth={nodeStyles.circle.strokeWidth}
            />
            <text x={0} y={5} textAnchor="middle" style={nodeStyles.text}>
              {rd3tProps.nodeDatum.name}
            </text>
          </g>
        )}
      />
    </div>
  )
}
