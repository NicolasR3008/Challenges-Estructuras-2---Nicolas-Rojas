// Nicolas Rojas Cabal - 2226088

import React, { useState } from "react";
import menuTree from "./naryTree";
import Sidebar from "./components/Sidebar";
import "./App.css";

function App() {
  const [selectedLink, setSelectedLink] = useState("");
  const [SelectedComponent, setSelectedComponent] = useState(null);

  
  const handleSelect = (link, component) => {
    setSelectedLink(link);
    setSelectedComponent(() => component);
  };

  return (
    <div className="app-container">
      <Sidebar
        menuTree={menuTree}
        onSelect={handleSelect}
        currentLink={selectedLink}
      />

      
      <div className="content-container">
        {SelectedComponent ? (
          <SelectedComponent />
        ) : (
          <div style={{ padding: "2rem" }}>
            <h2>Bienvenido</h2>
            <p>Selecciona una opción del menú lateral para ver el contenido.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
