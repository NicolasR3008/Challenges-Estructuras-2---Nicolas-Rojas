// Nicolas Rojas Cabal - 2226088

import React, { useState } from "react";
import "./Sidebar.css"; 

/**
  @param {Object} props
 */
function MenuItem({ node, level, onSelect, currentLink }) {
  const [expanded, setExpanded] = useState(false);
  const hasChildren = node.children && node.children.length > 0;

  
  const handleClickItem = () => {
    onSelect(node.link, node.component);
    if (hasChildren) {
      setExpanded((prev) => !prev);
    }
  };

  return (
    <div>
      <div
        className={`menu-item ${currentLink === node.link ? "active" : ""}`}
        style={{ paddingLeft: `${level * 16}px` }}
        onClick={handleClickItem}
      >
        {hasChildren && (
          <span
            className={`arrow ${expanded ? "arrow-down" : "arrow-right"}`}
          ></span>
        )}
        <span className="menu-title">{node.title}</span>
      </div>

      {hasChildren && expanded && (
        <div className="submenu">
          {node.children.map((child) => (
            <MenuItem
              key={child.link}
              node={child}
              level={level + 1}
              onSelect={onSelect}
              currentLink={currentLink}
            />
          ))}
        </div>
      )}
    </div>
  );
}


export default function Sidebar({ menuTree, onSelect, currentLink }) {
  return (
    <div className="sidebar-container">
      {menuTree.map((node) => (
        <MenuItem
          key={node.link}
          node={node}
          level={0}
          onSelect={onSelect}
          currentLink={currentLink}
        />
      ))}
    </div>
  );
}
