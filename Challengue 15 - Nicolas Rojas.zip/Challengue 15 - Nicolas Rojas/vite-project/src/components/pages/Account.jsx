// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Account() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Account Page</h1>
      <p>Aquí se muestran detalles de la cuenta.</p>
    </div>
  );
}
