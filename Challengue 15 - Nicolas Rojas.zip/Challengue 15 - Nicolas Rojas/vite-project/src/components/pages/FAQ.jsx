// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function FAQ() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>FAQ’s Page</h1>
      <p>Preguntas frecuentes.</p>
    </div>
  );
}
