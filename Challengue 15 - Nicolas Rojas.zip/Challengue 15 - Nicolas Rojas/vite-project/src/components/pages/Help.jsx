// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Help() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Help Page</h1>
      <p>Selecciona un ítem en Help.</p>
    </div>
  );
}
