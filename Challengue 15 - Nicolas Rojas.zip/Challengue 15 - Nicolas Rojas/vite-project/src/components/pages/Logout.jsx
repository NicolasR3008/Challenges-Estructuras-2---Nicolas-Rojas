// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Logout() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Logout</h1>
      <p>Se cerró la sesión.</p>
    </div>
  );
}
