// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Messages() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Messages Page</h1>
      <p>Aquí irían los mensajes.</p>
    </div>
  );
}
