// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function NetworkStatus() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Network Status</h1>
      <p>Estado de la red.</p>
    </div>
  );
}
