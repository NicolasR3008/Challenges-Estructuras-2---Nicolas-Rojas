// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Notifications() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Notifications Page</h1>
      <p>Administrar notificaciones.</p>
    </div>
  );
}
