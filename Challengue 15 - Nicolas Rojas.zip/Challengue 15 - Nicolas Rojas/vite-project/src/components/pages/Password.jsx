// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Password() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Password Page</h1>
      <p>Cambia tu contraseña aquí.</p>
    </div>
  );
}
