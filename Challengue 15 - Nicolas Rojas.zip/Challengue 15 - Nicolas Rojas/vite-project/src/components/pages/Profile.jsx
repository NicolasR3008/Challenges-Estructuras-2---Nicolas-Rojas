// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Profile() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Profile Page</h1>
      <p>Bienvenido a la página de Profile.</p>
    </div>
  );
}
