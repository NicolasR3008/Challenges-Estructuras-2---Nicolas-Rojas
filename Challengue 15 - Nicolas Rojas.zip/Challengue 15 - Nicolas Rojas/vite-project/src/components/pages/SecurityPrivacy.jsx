// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function SecurityPrivacy() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Security & Privacy</h1>
      <p>Opciones de seguridad y privacidad.</p>
    </div>
  );
}
