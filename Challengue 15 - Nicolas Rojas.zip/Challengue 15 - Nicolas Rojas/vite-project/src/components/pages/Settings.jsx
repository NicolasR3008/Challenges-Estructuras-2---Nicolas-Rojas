// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function Settings() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Settings Page</h1>
      <p>Elige una opción del submenú de Settings.</p>
    </div>
  );
}
