// Nicolas Rojas Cabal - 2226088

import React from "react";

export default function SubmitTicket() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Submit a Ticket</h1>
      <p>Formulario para enviar un ticket de soporte.</p>
    </div>
  );
}
