// Nicolas Rojas Cabal - 2226088
import Profile from "./components/pages/Profile";
import Messages from "./components/pages/Messages";
import Settings from "./components/pages/Settings";
import Account from "./components/pages/Account";
import SecurityPrivacy from "./components/pages/SecurityPrivacy";
import Password from "./components/pages/Password";
import Notifications from "./components/pages/Notifications";
import Help from "./components/pages/Help";
import FAQ from "./components/pages/FAQ";
import SubmitTicket from "./components/pages/SubmitTicket";
import NetworkStatus from "./components/pages/NetworkStatus";
import Logout from "./components/pages/Logout";


const menuTree = [
  {
    title: "Profile",
    link: "/profile",
    component: Profile,
    children: [],
  },
  {
    title: "Messages",
    link: "/messages",
    component: Messages,
    children: [],
  },
  {
    title: "Settings",
    link: "/settings",
    component: Settings,
    children: [
      {
        title: "Account",
        link: "/settings/account",
        component: Account,
        children: [],
      },
      {
        title: "Profile",
        link: "/settings/profile",
        component: Profile,
        children: [],
      },
      {
        title: "Security & Privacy",
        link: "/settings/security",
        component: SecurityPrivacy,
        children: [],
      },
      {
        title: "Password",
        link: "/settings/password",
        component: Password,
        children: [],
      },
      {
        title: "Notifications",
        link: "/settings/notifications",
        component: Notifications,
        children: [],
      },
    ],
  },
  {
    title: "Help",
    link: "/help",
    component: Help,
    children: [
      {
        title: "FAQ’s",
        link: "/help/faqs",
        component: FAQ,
        children: [],
      },
      {
        title: "Submit a Ticket",
        link: "/help/submit-ticket",
        component: SubmitTicket,
        children: [],
      },
      {
        title: "Network Status",
        link: "/help/network-status",
        component: NetworkStatus,
        children: [],
      },
    ],
  },
  {
    title: "Logout",
    link: "/logout",
    component: Logout,
    children: [],
  },
];

export default menuTree;
