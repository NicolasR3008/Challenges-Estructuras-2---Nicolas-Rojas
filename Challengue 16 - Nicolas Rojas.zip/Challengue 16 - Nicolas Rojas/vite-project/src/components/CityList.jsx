//Nicolas Rojas Cabal - 2226088

import React from "react";
import "../App.css";

const CityList = ({ cities, getPeople }) => {
  return (
    <div className="city-list">
      <h3>challengue 16</h3>
      {cities.map((city) => (
        <div key={city} style={{ marginBottom: "1rem" }}>
          <strong>{city}</strong>
          <ul>
            {getPeople(city).map((person) => (
              <li key={person.name}>
                {person.name} ({person.age} años)
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default CityList;
