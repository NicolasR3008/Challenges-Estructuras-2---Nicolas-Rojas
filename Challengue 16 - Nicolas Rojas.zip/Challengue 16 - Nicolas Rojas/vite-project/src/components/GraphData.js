//Nicolas Rojas Cabal - 2226088

class Graph {
  constructor() {
    this.nodes = [];
    this.adjList = {};
    this.people = [];
    this.cities = [];
  }

  addCity(cityName) {
    if (!this.adjList[cityName]) {
      this.nodes.push({
        id: cityName,
        label: cityName,
        type: "city",
        color: "#e63946",
      });
      this.adjList[cityName] = [];
      this.cities.push(cityName);
    }
  }

  addPerson(name, age, city) {
    if (!this.adjList[city]) {
      console.error(`La ciudad "${city}" no existe.`);
      return;
    }

    const personId = name;

    if (this.adjList[personId]) return;

    this.nodes.push({
      id: personId,
      label: `${name} (${age} años)`,
      type: "person",
      color: "#a8dadc",
    });

    this.adjList[personId] = [city];
    this.adjList[city].push(personId);
    this.people.push({ name, age, city });
  }

  getGraphData() {
    const links = [];

    for (const node in this.adjList) {
      for (const neighbor of this.adjList[node]) {
        if (node < neighbor) {
          links.push({ source: node, target: neighbor });
        }
      }
    }

    return {
      nodes: this.nodes,
      links,
    };
  }

  getPeopleInCity(cityName) {
    return this.people.filter((p) => p.city === cityName);
  }
}

export default Graph;
