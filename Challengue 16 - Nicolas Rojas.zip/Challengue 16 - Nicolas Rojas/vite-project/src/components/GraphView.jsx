//Nicolas Rojas Cabal - 2226088

import React from "react";
import { Graph as D3Graph } from "react-d3-graph";
import "../App.css";

const GraphView = ({ data }) => {
  const config = {
    nodeHighlightBehavior: true,
    node: {
      size: 400,
      fontColor: "#000000",
      highlightStrokeColor: "#1d3557",
      labelProperty: "label",
      colorProperty: "color",
    },
    link: {
      highlightColor: "#457b9d",
    },
    height: 500,
    width: 800,
  };

  const onClickNode = (nodeId) => {
    alert(`Clicked node ${nodeId}`);
  };

  return (
    <div className="graph-view">
      <D3Graph
        id="graph-id"
        data={data}
        config={config}
        onClickNode={onClickNode}
      />
    </div>
  );
};

export default GraphView;
