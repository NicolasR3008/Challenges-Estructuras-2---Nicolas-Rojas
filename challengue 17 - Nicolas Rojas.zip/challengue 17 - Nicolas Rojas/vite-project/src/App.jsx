import React, { useEffect, useState } from "react";
import Graph from "./components/GraphData";
import GraphView from "./components/GraphView";
import CityList from "./components/CityList";
import styles from "./App.module.scss";

function App() {
  const [graph] = useState(new Graph());
  const [graphData, setGraphData] = useState({ nodes: [], links: [] });

  useEffect(() => {
    graph.addCity("Cali");
    graph.addCity("Bogotá");

    graph.addPerson("Ana", 22, "Cali");
    graph.addPerson("Luis", 30, "Cali");
    graph.addPerson("Camila", 25, "Cali");
    graph.addPerson("Pedro", 28, "Cali");

    graph.addPerson("Maria", 27, "Bogotá");
    graph.addPerson("Carlos", 35, "Bogotá");
    graph.addPerson("Julian", 24, "Bogotá");
    graph.addPerson("Laura", 29, "Bogotá");

    setGraphData(graph.getGraphData());
  }, [graph]);

  return (
    <div className={styles.appContainer}>
      <CityList
        cities={graph.cities}
        getPeople={(city) => graph.getPeopleInCity(city)}
      />
      <GraphView data={graphData} />
    </div>
  );
}

export default App;
