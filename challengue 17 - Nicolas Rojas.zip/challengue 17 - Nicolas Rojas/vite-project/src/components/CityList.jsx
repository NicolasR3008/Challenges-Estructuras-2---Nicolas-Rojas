//Nicolas Rojas Cabal - 2226088

import React from "react";
import styles from "./CityList.module.scss";

const CityList = ({ cities, getPeople }) => {
  return (
    <div className={styles.cityList}>
      <h3>Challenge 17</h3>
      {cities.map((city) => (
        <div key={city} className={styles.cityItem}>
          <strong>{city}</strong>
          <ul>
            {getPeople(city).map((person) => (
              <li key={person.name}>
                {person.name} ({person.age} años)
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default CityList;
