//Nicolas Rojas - 2226088
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import ComponentApp from './ComponentApp';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ComponentApp />
  </StrictMode>
);